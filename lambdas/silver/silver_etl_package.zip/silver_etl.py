"""
Silver Layer ETL - Data Cleansing and Standardization
Author: Data Engineering Team
Purpose: Transform Bronze data (raw) into Silver data (cleaned, standardized)

Transformations Applied:
1. Flatten nested JSON structures
2. Standardize column names (lowercase, snake_case)
3. Remove duplicate records
4. Handle missing values
5. Data type validation and conversion
6. Enrich with processing metadata
7. Partition by event_year, event_month, event_day
"""

import json
import boto3
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datetime import datetime
from io import BytesIO
import os
import logging

# Configure logging
log_level = os.environ.get('LOG_LEVEL', 'INFO')
logger = logging.getLogger()
logger.setLevel(log_level)

# AWS clients
s3_client = boto3.client('s3')
glue_client = boto3.client('glue')

# Environment variables
BRONZE_BUCKET = os.environ.get('BRONZE_BUCKET_NAME')
SILVER_BUCKET = os.environ.get('SILVER_BUCKET_NAME')
GLUE_DATABASE = os.environ.get('GLUE_DATABASE_NAME')


def lambda_handler(event, context):
    """
    Main Lambda handler for Silver layer ETL
    
    Event structure:
    {
        "source_bucket": "bronze-bucket-name",
        "target_bucket": "silver-bucket-name",
        "table_name": "bronze",
        "triggered_by": "eventbridge-scheduler"
    }
    """
    logger.info("=" * 80)
    logger.info("SILVER LAYER ETL - Starting execution")
    logger.info("=" * 80)
    
    try:
        # Get configuration from event or environment
        source_bucket = event.get('source_bucket', BRONZE_BUCKET)
        target_bucket = event.get('target_bucket', SILVER_BUCKET)
        table_name = event.get('table_name', 'bronze')
        
        logger.info(f"Source bucket: {source_bucket}")
        logger.info(f"Target bucket: {target_bucket}")
        logger.info(f"Table name: {table_name}")
        
        # Get latest partition from Bronze
        partitions = get_latest_bronze_partitions(source_bucket, table_name)
        
        if not partitions:
            logger.warning("No new partitions found in Bronze layer")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'No new data to process',
                    'processed_files': 0
                })
            }
        
        logger.info(f"Found {len(partitions)} partitions to process")
        
        # Process each partition
        processed_count = 0
        for partition_path in partitions:
            logger.info(f"Processing partition: {partition_path}")
            
            # Read data from Bronze
            df = read_bronze_data(source_bucket, partition_path)
            
            if df is None or df.empty:
                logger.warning(f"No data in partition: {partition_path}")
                continue
            
            logger.info(f"Loaded {len(df)} records from Bronze")
            
            # Apply transformations
            df_clean = apply_transformations(df)
            
            logger.info(f"After cleansing: {len(df_clean)} records")
            
            # Write to Silver
            write_silver_data(df_clean, target_bucket)
            
            processed_count += 1
        
        logger.info("=" * 80)
        logger.info(f"SILVER LAYER ETL - Completed successfully")
        logger.info(f"Processed {processed_count} partitions")
        logger.info("=" * 80)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Silver layer ETL completed successfully',
                'processed_partitions': processed_count,
                'timestamp': datetime.utcnow().isoformat()
            })
        }
        
    except Exception as e:
        logger.error(f"ERROR in Silver ETL: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Silver layer ETL failed'
            })
        }


def get_latest_bronze_partitions(bucket, table_name):
    """Get list of latest Bronze partitions to process"""
    try:
        # List objects in Bronze bucket with partitions
        response = s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix='bronze/partition_year='
        )
        
        if 'Contents' not in response:
            return []
        
        # Get unique partition paths
        partitions = set()
        for obj in response['Contents']:
            key = obj['Key']
            if key.endswith('.parquet'):
                # Extract partition path: bronze/partition_year=YYYY/partition_month=MM/partition_day=DD/
                parts = key.split('/')
                if len(parts) >= 5:
                    partition_path = '/'.join(parts[:4]) + '/'
                    partitions.add(partition_path)
        
        return list(partitions)
        
    except Exception as e:
        logger.error(f"Error getting Bronze partitions: {str(e)}")
        return []


def read_bronze_data(bucket, partition_path):
    """Read all Parquet files from a Bronze partition"""
    try:
        # List all Parquet files in the partition
        response = s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix=partition_path
        )
        
        if 'Contents' not in response:
            return None
        
        # Read and concatenate all Parquet files
        dataframes = []
        for obj in response['Contents']:
            key = obj['Key']
            if key.endswith('.parquet'):
                logger.info(f"Reading: {key}")
                
                # Download Parquet file
                obj_response = s3_client.get_object(Bucket=bucket, Key=key)
                parquet_data = obj_response['Body'].read()
                
                # Read Parquet into DataFrame
                df = pd.read_parquet(BytesIO(parquet_data))
                dataframes.append(df)
        
        if not dataframes:
            return None
        
        # Concatenate all DataFrames
        df_combined = pd.concat(dataframes, ignore_index=True)
        return df_combined
        
    except Exception as e:
        logger.error(f"Error reading Bronze data: {str(e)}")
        return None


def apply_transformations(df):
    """Apply data cleansing and standardization transformations"""
    try:
        logger.info("Applying transformations...")
        
        # 1. Flatten nested structures (already done in Bronze for JSON normalize)
        logger.info("Step 1: Structures already flattened")
        
        # 2. Standardize column names to lowercase snake_case
        df.columns = [col.lower().replace('.', '_') for col in df.columns]
        logger.info(f"Step 2: Standardized {len(df.columns)} column names")
        
        # 3. Remove exact duplicates
        initial_count = len(df)
        df = df.drop_duplicates()
        duplicates_removed = initial_count - len(df)
        if duplicates_removed > 0:
            logger.info(f"Step 3: Removed {duplicates_removed} duplicate records")
        
        # 4. Handle missing values (strategy: keep nulls for now, can be customized)
        null_counts = df.isnull().sum()
        if null_counts.any():
            logger.info(f"Step 4: Found null values in columns: {null_counts[null_counts > 0].to_dict()}")
        
        # 5. Data type validation (numeric columns should be float64)
        numeric_columns = df.select_dtypes(include=['int64', 'int32', 'float32', 'float64']).columns
        for col in numeric_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        logger.info(f"Step 5: Validated {len(numeric_columns)} numeric columns")
        
        # 6. Add Silver layer metadata
        processing_time = datetime.utcnow()
        df['silver_processing_timestamp'] = processing_time.isoformat()
        df['silver_processing_date'] = processing_time.date().isoformat()
        df['data_quality_score'] = calculate_quality_score(df)
        
        logger.info("Step 6: Added Silver layer metadata")
        
        # 7. Add partition columns for Silver layer (based on ingestion timestamp)
        if 'ingestion_timestamp' in df.columns:
            df['event_date'] = pd.to_datetime(df['ingestion_timestamp'])
            df['event_year'] = df['event_date'].dt.year
            df['event_month'] = df['event_date'].dt.month
            df['event_day'] = df['event_date'].dt.day
        else:
            # Fallback to processing time
            df['event_year'] = processing_time.year
            df['event_month'] = processing_time.month
            df['event_day'] = processing_time.day
        
        logger.info("Step 7: Added partition columns (event_year, event_month, event_day)")
        
        logger.info(f"Transformations complete. Final record count: {len(df)}")
        return df
        
    except Exception as e:
        logger.error(f"Error in transformations: {str(e)}")
        raise


def calculate_quality_score(df):
    """Calculate a simple data quality score (0-100)"""
    try:
        # Calculate completeness score
        total_cells = df.size
        non_null_cells = df.count().sum()
        completeness = (non_null_cells / total_cells) * 100 if total_cells > 0 else 0
        
        # For now, quality score = completeness
        # Can be extended with more sophisticated metrics
        return round(completeness, 2)
        
    except:
        return 100.0


def write_silver_data(df, bucket):
    """Write cleaned data to Silver bucket with partitioning"""
    try:
        # Group by partition columns
        partition_cols = ['event_year', 'event_month', 'event_day']
        
        grouped = df.groupby(partition_cols)
        
        for (year, month, day), group_df in grouped:
            # Create partition path
            partition_path = f"silver/partition_year={year}/partition_month={month:02d}/partition_day={day:02d}"
            
            # Generate filename
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"car_telemetry_{timestamp}.parquet"
            s3_key = f"{partition_path}/{filename}"
            
            # Remove partition columns from data (they're in the path)
            df_to_write = group_df.drop(columns=partition_cols, errors='ignore')
            
            # Convert to Parquet
            parquet_buffer = BytesIO()
            df_to_write.to_parquet(
                parquet_buffer,
                engine='pyarrow',
                compression='snappy',
                index=False
            )
            parquet_buffer.seek(0)
            
            # Upload to S3
            s3_client.put_object(
                Bucket=bucket,
                Key=s3_key,
                Body=parquet_buffer.getvalue(),
                ContentType='application/octet-stream',
                Metadata={
                    'layer': 'silver',
                    'format': 'parquet',
                    'compression': 'snappy',
                    'partition-year': str(year),
                    'partition-month': str(month),
                    'partition-day': str(day),
                    'record-count': str(len(df_to_write)),
                    'processing-timestamp': datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"✓ Written {len(df_to_write)} records to: {s3_key}")
        
        logger.info(f"Successfully wrote data to Silver bucket: {bucket}")
        
    except Exception as e:
        logger.error(f"Error writing to Silver: {str(e)}")
        raise
