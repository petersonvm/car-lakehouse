"""
AWS Lambda Function - Data Ingestion
Converts CSV and JSON files from landing bucket to Parquet format in bronze bucket
"""

import json
import boto3
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
from io import BytesIO
import os
from urllib.parse import unquote_plus
from datetime import datetime

# Initialize S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    Lambda handler for S3 triggered events
    Processes CSV files and converts them to Parquet format
    
    Args:
        event: S3 event notification
        context: Lambda context object
        
    Returns:
        dict: Response with status and processed files
    """
    
    # Get environment variables
    bronze_bucket = os.environ.get('BRONZE_BUCKET')
    
    print(f"Ingestion Lambda started at {datetime.utcnow().isoformat()}")
    print(f"Bronze bucket: {bronze_bucket}")
    
    processed_files = []
    failed_files = []
    
    try:
        # Process each record in the S3 event
        for record in event['Records']:
            try:
                # Extract S3 event information
                source_bucket = record['s3']['bucket']['name']
                source_key = unquote_plus(record['s3']['object']['key'])
                file_size = record['s3']['object']['size']
                
                print(f"\n{'='*60}")
                print(f"Processing file: {source_key}")
                print(f"Source bucket: {source_bucket}")
                print(f"File size: {file_size} bytes")
                
                # Determine file type
                file_extension = source_key.lower().split('.')[-1]
                
                if file_extension not in ['csv', 'json']:
                    print(f"Skipping unsupported file type: {source_key} (.{file_extension})")
                    continue
                
                print(f"File type detected: {file_extension.upper()}")
                
                # Get current timestamp for partitioning
                ingestion_time = datetime.utcnow()
                
                # Create partitioned path with partition_ prefix to avoid conflicts with data columns
                # bronze/partition_year=YYYY/partition_month=MM/partition_day=DD/filename.parquet
                base_filename = source_key.rsplit('.', 1)[0]  # Remove original extension
                partitioned_path = f"partition_year={ingestion_time.year}/partition_month={ingestion_time.month:02d}/partition_day={ingestion_time.day:02d}"
                dest_key = f"bronze/{partitioned_path}/{base_filename}.parquet"
                
                print(f"Partitioned destination: {dest_key}")
                print(f"Partition: {partitioned_path}")
                
                # Read file from S3
                print(f"Reading {file_extension.upper()} file from S3...")
                response = s3_client.get_object(Bucket=source_bucket, Key=source_key)
                file_content = response['Body'].read()
                
                # Load into Pandas DataFrame based on file type
                print(f"Loading {file_extension.upper()} into DataFrame...")
                
                if file_extension == 'csv':
                    # Load CSV into DataFrame
                    df = pd.read_csv(BytesIO(file_content))
                elif file_extension == 'json':
                    # Load JSON into DataFrame
                    json_data = json.loads(file_content.decode('utf-8'))
                    
                    # Handle both single object and array of objects
                    if isinstance(json_data, dict):
                        # Single JSON object - convert to single-row DataFrame
                        df = pd.json_normalize(json_data)
                    elif isinstance(json_data, list):
                        # Array of JSON objects
                        df = pd.json_normalize(json_data)
                    else:
                        raise ValueError(f"Unsupported JSON structure: {type(json_data)}")
                
                # Log DataFrame info
                print(f"DataFrame shape: {df.shape}")
                print(f"Columns: {list(df.columns)}")
                print(f"Data types:\n{df.dtypes}")
                
                # Normalize numeric types to avoid schema conflicts
                # Convert all numeric columns to float64 for consistency
                for col in df.columns:
                    if df[col].dtype in ['int64', 'int32', 'float32']:
                        df[col] = df[col].astype('float64')
                
                print(f"Data types after normalization:\n{df.dtypes}")
                
                # Add metadata columns
                df['ingestion_timestamp'] = datetime.utcnow().isoformat()
                df['source_file'] = source_key
                df['source_bucket'] = source_bucket
                df['source_format'] = file_extension.upper()
                
                # Note: Partition columns (year, month, day) are NOT added to the data
                # They come from the S3 folder structure: /year=YYYY/month=MM/day=DD/
                # This prevents duplicate columns in the Glue table
                
                # Convert DataFrame to Parquet in memory
                print("Converting to Parquet format...")
                parquet_buffer = BytesIO()
                
                # Convert to PyArrow Table and write to Parquet
                table = pa.Table.from_pandas(df)
                pq.write_table(
                    table,
                    parquet_buffer,
                    compression='snappy',
                    version='2.6'
                )
                
                # Reset buffer position
                parquet_buffer.seek(0)
                parquet_size = len(parquet_buffer.getvalue())
                
                print(f"Parquet size: {parquet_size} bytes")
                print(f"Compression ratio: {(1 - parquet_size/file_size)*100:.2f}%")
                
                # Upload Parquet file to bronze bucket
                print(f"Uploading to bronze bucket: {bronze_bucket}")
                s3_client.put_object(
                    Bucket=bronze_bucket,
                    Key=dest_key,
                    Body=parquet_buffer.getvalue(),
                    ContentType='application/octet-stream',
                    Metadata={
                        'source-file': source_key,
                        'source-bucket': source_bucket,
                        'original-format': file_extension,
                        'rows': str(len(df)),
                        'columns': str(len(df.columns)),
                        'ingestion-timestamp': datetime.utcnow().isoformat(),
                        'partition-year': str(ingestion_time.year),
                        'partition-month': str(ingestion_time.month),
                        'partition-day': str(ingestion_time.day),
                        'partitioned': 'true'
                    }
                )
                
                print(f"✅ Successfully processed: {source_key} -> {dest_key}")
                
                # Delete the source file from landing bucket after successful processing
                try:
                    print(f"Deleting source file from landing bucket: {source_key}")
                    s3_client.delete_object(
                        Bucket=source_bucket,
                        Key=source_key
                    )
                    print(f"✅ Source file deleted: {source_key}")
                except Exception as delete_error:
                    print(f"⚠️ Warning: Failed to delete source file {source_key}: {str(delete_error)}")
                    # Don't fail the whole process if deletion fails
                
                processed_files.append({
                    'source': f"s3://{source_bucket}/{source_key}",
                    'destination': f"s3://{bronze_bucket}/{dest_key}",
                    'rows': len(df),
                    'columns': len(df.columns),
                    'original_size': file_size,
                    'parquet_size': parquet_size,
                    'compression_ratio': f"{(1 - parquet_size/file_size)*100:.2f}%",
                    'source_deleted': True,
                    'partitioned': True,
                    'partition_path': partitioned_path,
                    'partition_year': ingestion_time.year,
                    'partition_month': ingestion_time.month,
                    'partition_day': ingestion_time.day
                })
                
            except Exception as file_error:
                error_msg = f"Error processing file {source_key}: {str(file_error)}"
                print(f"❌ {error_msg}")
                failed_files.append({
                    'file': source_key,
                    'error': str(file_error)
                })
                # Continue processing other files
                continue
        
        # Prepare response
        response = {
            'statusCode': 200 if not failed_files else 207,  # 207 = Multi-Status
            'body': json.dumps({
                'message': 'Ingestion process completed',
                'processed_files': len(processed_files),
                'failed_files': len(failed_files),
                'details': {
                    'processed': processed_files,
                    'failed': failed_files
                }
            }, indent=2)
        }
        
        print(f"\n{'='*60}")
        print(f"Summary: {len(processed_files)} processed, {len(failed_files)} failed")
        print(f"Lambda execution completed at {datetime.utcnow().isoformat()}")
        
        return response
        
    except Exception as e:
        error_msg = f"Critical error in lambda_handler: {str(e)}"
        print(f"❌ {error_msg}")
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Ingestion process failed',
                'error': str(e)
            })
        }
